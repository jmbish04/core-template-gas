# History

## Version 2.0.0 | 2025-09-18

- Migrate `src/client/runGas.js` to `src/client/lib/runGas.js`.
- TypeScript support and the `--ts` flag for installation.
- More robust mocking for `google.script.run`, including success and failure handling.
- Updated table of contents in `README.md`.
- Explicit mention of Vitest as the testing framework.
- Creation of `GEMINI.md`

## Version 1.3.2 | 2025-06-06

- Update dependencies
- Update formatting
- Migrate from Jest to Vitest

## Version 1.3.1 | 2024-09-05

- Add support for rest parameters in exported functions
- Add code of conduct
- Add contributing guide

## Version 1.3.0 | 2024-09-04

- Automatic compilation of TailwindCSS
- Added PostCSS and Autoprefixer
- Upgrade Vite to v5
- Upgrade DaisyUI to v4
- Added dist folder to .gitignore

## Version 1.2.0 | 2024-08-22

- Write full documentation in README
- Variable name change in environment management dependency

## Version 1.1.0 | 2024-06-07

- Upgrade Vite plugin to use ASM to generate the `dist/exports.js` file
- Bundle all server-side and client-side code
- Include library buliding mode, supporting NPM and copy & paste

## Version 1.0.0 | 2024-06-07

- Migrate from TypeScript to JSDoc
- Add a generic favicon for local development
- Add credits to the console
- Add Vite config file for Apps Script
- Add Vite plugin for Apps Script
- Migrate client-side code to `src/client`
- Migrate Apps Script code to `src/server`
- Add environment management tool
- Add HISTORY.md

## Version 0.0.1 | 2023-06-21

- Initial deployment
- TypeScript, Alpine.js, TailwindCSS, DaisyUI
- Husky, Jest, ESLint, Prettier, Vite
